from audioin import takecommand
from audioout import speak
import wikipedia as wiki
import webbrowser as wb

def search():
    speak("What to search?")
    term=takecommand()
    speak("SEARCHING........")
    result=wiki.summary(term,sentences=3)
    speak("This Is What I Found")
    print(result)
    speak("Would  you like me  to read this  for  you? ")
    ch=takecommand().lower().strip()
    if 'y' in ch:
        speak(f"Okay.....{result}")
    else:
        speak("Fine")
    speak(f"that's all about {term}")

def search_on_youtube():
    term=takecommand()
    wb.open("https://www.youtube.com/results?search_query=%s" % term)

def openwebsite():
    speak("WHICH SITE TO OPEN?")
    site=takecommand()
    speak(f"Please wait while i open {site} for you")
    wb.open(f"https://www.{site}.com")



    
