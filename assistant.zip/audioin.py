#IMPORT PACKAGE OR MODULE
import speech_recognition as sr
#CREATE RECOGNIZER
recognizer=sr.Recognizer()
def takecommand():
    #RECORD AUDIO FROM MIC
    print("LISTENING.........")
    with sr.Microphone() as source:
        audio=recognizer.listen(source,phrase_time_limit=3)
        print(audio)
    #CONVERT AUDIO TO STRING
    data=recognizer.recognize_google(audio)
    return data.lower().strip()
