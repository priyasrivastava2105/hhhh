from audioin import takecommand
from audioout import speak
from search import *
from datetime import  datetime
from music import playsong
flag = True
while True:
    if flag:
        speak("Hi, I am friday. How may  I help you?")
        flag = False
    command=takecommand()
    if 'time'  in command:
        t=datetime.now().strftime("%I:%M %p")
        speak(t)
        print(t)
    elif 'what' in command or 'search' in command:
        search()
    elif 'play' in command  or 'song' in command  or 'music'  in command:
        playsong()
    else:
        speak("Sorry I could not understand. Speak again")

