from audioin import takecommand
from audioout import speak
from googlesearch import search

from bs4  import BeautifulSoup
import re
from urllib import request

def search_google():
    #SEARCH THE TERM ON INTERNET
    term = "Computer Science".replace(" ","+")
    # url = f"https://www.google.com/search?source=hp&ei=cUO5XdHFJcXTvgTSor6IBA&q={term}&oq={term}&gs_l=psy-ab.3..0l10.2444.3247..3506...0.0..0.238.1134.0j6j1......0....1..gws-wiz.....6..0i362i308i154i357j0i131j0i10.ZEz3Duh7FSc&ved=0ahUKEwiRwvGqwsPlAhXFqY8KHVKRD0EQ4dUDCAY&uact=5"
    url = "https://www.bing.com/search?q={term}&qs=n&form=QBLH&sp=-1&pq=face&sc=9-4&sk=&cvid=FAAC5BF11822419A96731D97AFBA3A0D"
    result = request.urlopen(url)
    data =  BeautifulSoup(result,"lxml")
    anchors = [str(x) for x in data.find_all('a')]
    #EXTRACT THE REQUIRED RESULT
    # print(anchors)
    unique=[x for x in anchors if term.lower() in x.lower()]
    print(unique)



search_google()