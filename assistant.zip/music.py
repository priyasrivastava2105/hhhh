from urllib import request
import re
import webbrowser as wb 
from bs4  import BeautifulSoup
#from pytube import YouTube
from time import sleep
import os
import pafy
from audioin import takecommand
from audioout  import speak
try:
    os.mkdir("downloads")
except:pass
def playsong():
    speak("Play music of  which artist?")
    term=takecommand()
    speak("which song?")
    song=takecommand()
    term=term.replace(" ","+")
    URL="https://www.youtube.com/results?search_query=%s" 
    source = request.urlopen(URL %term)
    data =  BeautifulSoup(source,"lxml")
    anchors=[str(x) for x in data.find_all('a')]
    videos=[x for x in anchors if "watch?v=".lower() in x.lower()]
    sng=[x for x in videos if song.lower() in x.lower()]
    data=[]
    rx = "href=\"\/watch\?v=[a-zA-z0-9]+"
    for x in sng:
        data.append(re.findall(rx,x))
    nd=[]
    for x in data:
        for  y in x:
            nd.append(y)
    nd=[x[6:] for x in nd]
    unique=list(set(nd))
    wb.open(f"https://www.youtube.com{unique[0]}")
    print("Playing Music")
    sleep(10)
    speak("Do you want to download this song?")
    ch=takecommand()
    if 'y' in ch:
        speak("okay. Please wait while I download the song. ")
        save(f"https://www.youtube.com{unique[0]}")
    else:
        speak("fine")
   
def save(url=None):
    try:
        video =  pafy.new(url)
        song = video.streams
        for i in song:
            print(i)
        best = video.getbest()
        best.download()
    except Exception as e:
        print(e)
#playsong("Font minor remember the name","Official")



    


