# IMPORT PACKAGE OR MODULES
import pyttsx3 as pts
# CREATE  ENGINE
engine=pts.init()
# CONFIGURATION SETTING
voices=engine.getProperty("voices")
#print(voices)
#print(voices[1].name)
engine.setProperty("voice",voices[1].id)
rate=engine.getProperty("rate")
#print(rate)
engine.setProperty("rate",rate-50)
# SPEAK TEXT
def speak(data):
    print("SPEAKING....")
    engine.say(data)
    print(data)
    # RUN AND WAIT
    engine.runAndWait()

